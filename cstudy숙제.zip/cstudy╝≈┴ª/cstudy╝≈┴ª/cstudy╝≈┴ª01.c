﻿빌드 시작...
1>------ 빌드 시작: 프로젝트: cstudy숙제, 구성: Debug x64 ------
1>cstudy숙제.c
1>cstudy숙제.vcxproj -> C:\Users\dlssh\Desktop\아이콘\코딩\cstudy숙제\x64\Debug\cstudy숙제.exe
========== 빌드: 1 성공, 0 실패, 0 최신 업데이트, 0 건너뛰기 ==========
