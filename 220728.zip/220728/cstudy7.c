#include<stdio.h>
struct Student1
{
	int xp;
	int yp;
}typedef d2;

struct Student1
{
	int xp;
	int yp;
	int zp;
}typedef d3;

struct ani
{
	char name[10];
	int age;
	char tribe[50];
}typedef ani;

int main()
{
	
	return 0;
}