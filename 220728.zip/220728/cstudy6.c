#include<stdio.h>
struct Student
{
	int num;
	int score;
}typedef Stu;
int main()
{
	Stu s1 = { 1,50 };
	Stu s2 = { .num = 2,60 };
	Stu s3;
	s3.num = 3;
	s3.score = 70;
	return 0;
}