package snippet;

public class Snippet {
	public static void Main(String[] args) {
			System.out.println("MyJava");
		}
}

