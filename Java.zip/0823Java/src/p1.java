import java.util.Scanner;

class Person{
	// 사람 클래스 :: 부모 클래스, 상위 클래스
	private String name;	// 이름
	private int age;       // 나이
	// 멤버: 이름, 나이
	
	public Person(String n, int g){
		this.name=n;
		this.age=g;
	}
	
	public void setName(String n) {this.name=n;}
	public void setAge(int g) {this.age=g;}
	
	
	public String getName() {return this.name;}
	public int getAge() {return this.age;}
	
	public void print_P() {
		System.out.println("사람 정보");
		System.out.println("이름: "+this.name);
		System.out.println("나이: "+this.age);
	}
}

class Student extends Person{
	
	private String name2;
	
	
	public Student(String n, int g,String name2 ) {
		super(n, g);	
		this.name2=name2;	
	}
	
	public void setName2(String n) {this.name2=n;}
	public String getName2() {return this.name2;}
	public void print_S() {
		System.out.println("사람 정보&소속");
		System.out.println("이름: "+this.getName());
		System.out.println("나이: "+this.getAge());
		System.out.println("학교이름: "+this.name2);
	}
}

class Teacher extends Person{
	
	private String name2;
	
	public Teacher(String n, int g,String name2 ) {
		super(n, g);	
		this.name2=name2;	
	}
	
	public void setName2(String n) {this.name2=n;}
	public String getName2() {return this.name2;}
	public void print_T() {
		System.out.println("앞사람 정보");
		System.out.println("이름: "+this.getName());
		System.out.println("나이: "+this.getAge());
		System.out.println("소속: "+this.name2);
	}
}



public class p1 {
	public static void main(String args[]) {
		Scanner s=new Scanner(System.in);
	
		Person p=new Person("김성환", 26);
		Student stu=new Student("김성환", 26,"경북대");
		Teacher tea=new Teacher("김경북",12,"경북산업");
		
	p.print_P();
	System.out.println();
	stu.print_S();
	System.out.println();
	tea.print_T();
}
}