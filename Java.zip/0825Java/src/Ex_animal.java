
abstract class Animal{	// 동물 클래스 (추상 클래스)
	// 추상 메소드 2개를 선언
	abstract String getName();
	abstract void printCry();
}

class Cat extends Animal{	// 고양이 클래스 (Animal 클래스 구체화)
	private String name;
	public Cat() {
		this.name="고양이";
	}
	// Animal 클래스의 추상 메소드 2가지 구현
	public String getName() {
		return this.name;
	}
	public void printCry() {
		System.out.println("야오오옹");
	}
	// 이렇게 구현하고나면 빨간줄이 없어짐
}

class Dog extends Animal{	// 강아지 클래스 (Animal 클래스 구체화)
	private String name;
	public Dog() {
		this.name="강아지";
	}
	// Animal 클래스의 추상 메소드 2가지 구현
	public String getName() {
		return this.name;
	}
	public void printCry() {
		System.out.println("월월월");
	}
	// 이렇게 구현하고나니 빨간줄 없어짐
}

public class Ex_animal {
	public static void main(String args[]) {
		// 고양이와 강아지 객체 생성
		Cat c=new Cat();
		Dog d=new Dog();
		// 각 생성자에서 요구하는 매개변수가 없음
		
		// 출력 결과::
		// 고양이의 울음소리는 야오오옹 (c 객체 이용해서 출력)
		System.out.print(c.getName()+"의 울음소리는 ");
		c.printCry();	// "야오오옹" 출력
		// 강아지의 울음소리는 월월월 (d 객체 이용해서 출력)
		System.out.print(d.getName()+"의 울음소리는 ");
		d.printCry();
	}
}




