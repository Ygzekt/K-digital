// extends를 이용한 상속을 계속 배워왔음
// 추상 클래스가 이 상속을 더 적극적으로 이용
// 추상 클래스 :: "추상적인 클래스", 구체적으로 정의되지 않은 클래스
// 추상 클래스는 추상 메소드를 하나라도 포함하고 있어야함 (?)
// 추상 클래스를 통해선 정상적으로 객체를 생성할 수가 없음
// 그 말은 즉, 추상 클래스는 반드시 상속받아져서 구체화가 필요함->상속
// 추상 메소드 :: "추상적인 메소드", 구체적으로 정의되지 않은 메소드

abstract class Person{	// 추상 클래스로 만듬
	// 추상 클래스로 만들기 위해서는, abstract 키워드가 필요
	// 추상 메소드 또한 abstract 키워드가 필요
	abstract public void printName();
	abstract public void print();
}

class Me extends Person{	// Person 클래스 구체화
	// 추상 클래스를 상속받고 난 뒤로 빨간줄이 생기는 이유는
	// 추상 메소드를 구체화하지 않았기 때문
	// 메소드를 구체화한다 = 중괄호를 열어서 명령문을 따로 작성
	
	private String name;	// 제 자신의 이름 저장
	public Me(String n) {
		this.name=n;
	}
	
	public void printName() {
		// 추상 메소드 printName()을 상속받아 구체화하고 있는 과정
		System.out.println("제 이름은 "+this.name+"입니다.");
	}
	public void print() {
		System.out.println("잘 부탁드립니다!!!");
	}
	// 추상 메소드 2개를 구체화하고나면 오류가 없어짐
	// "반드시 추상 클래스 안에 있는 추상 메소드에 대한 정의를 해야함"
}

public class Java0825 {
	public static void main(String args[]) {
		// Person p=new Person();
		// 추상 클래스는 객체 생성 불가능
		Me m=new Me("이유나");
		
		// 추상 클래스에 있던 메소드 정의한 뒤 사용
		m.printName();	// "제 이름은 이유나입니다."
		m.print();		// "잘 부탁드립니다!!!"
	}
}






