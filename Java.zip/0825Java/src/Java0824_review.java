// 상속의 개념, 적용하는 방법+super(), 오버라이딩

class Phone{	// 부모 클래스
	private String name;	// 폰 기종 이름
	private String num;		// 폰 번호
	// 멤버 변수: name, num
	// 생성자엔 어떤 명령문이든 쓸 수 있지만, 주로 변수 초기화에 많이 사용
	public Phone(String na, String nu) {
		this.name=na;
		this.num=nu;
	}
	public String getName() {return this.name;}
	public String getNum() {return this.num;}
	public void print() {
		System.out.println("< Phone의 print()가 실행되었습니다. >");
		System.out.println("휴대폰 정보");
		System.out.println("폰 기종: "+this.name);
		System.out.println("폰 번호: "+this.num);
	}
}

class SmartPhone extends Phone{	// 자식 클래스
	private String androidver;	// 안드로이드 버전
	private String account;		// 연동 계정
	// 멤버 변수: androidver, account, name, num
	// 부모 클래스에 생성자가 만들어지면 자식 클래스에서도 해당 생성자 사용해야함
	// 이를 위해서, super()를 주로 사용을 함
	public SmartPhone(String na, String nu, String a) {
		super(na, nu);	// 부모 클래스에 있는 name, num 초기화
		this.androidver="13";
		this.account=a;
	}
	// 부모 클래스에 있는 함수와 자기 자신에게 있는 함수가 동일한 이름일때,
	// 자기 자신에게 있는 함수를 우선시함
	// 오버라이딩의 개념 (오버로딩과 구분해주세요)
	public void print() {
		System.out.println("< SmartPhone의 print()가 실행되었습니다. >");
		System.out.println("스마트폰 정보");
		System.out.println("폰 기종: "+this.getName());
		System.out.println("폰 번호: "+this.getNum());
		System.out.println("안드로이드 버전: "+this.androidver);
		System.out.println("계정: "+this.account);
	}
}

public class Java0824_review {
	public static void main(String args[]) {
		// 객체를 각각 생성
		Phone p=new Phone("보디가드", "010-6659-6311");
		SmartPhone sp=new SmartPhone("갤럭시 S20", "010-2272-6311", "dbskakfl57913");
		
		p.print();	// Phone의 print() 실행
		System.out.println();
		sp.print();	// SmartPhone의 print() 실행
				// 오버라이딩 적용됨
	}
}







