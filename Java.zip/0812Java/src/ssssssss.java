//extends를 이용한 상속을 계속 배워왔음
//추상 클래스가 이 상속을 이용
//추상 클래스 :: "추상적인 클래스", 구체적으로 정의 되지 않은 클래스
// 추상 클래스를 통해서 정상적으로 객체를 생성할 수가 없음
//추상 클래스는 추상 메소드를 하나라도 포함하고 있어야함.
//그 말은 즉., 추상 클래스는 반드시 상속받아져서 구체화가 필요함(상속)
//추상 메소드 :: "추상적인 메소드", 구체적으로 정의되지 않은 메소드
//상속의 개념, 적용하는 방법+super(), 오버라이딩

class Phone{  //추상 클래스로 만듦.
	           // 추상 클래스로 만들기 위해서는, abstract 키워드 필요
	          //추상 메소드 또한 abstract키워드가 필요
	private String name; //폰 기종 이름
	private String num;  //
//보호 클래스  , 생성자엔 어떤 명령문이든 쓸수있지만, 주로 변수 초기화에 많이 사용함
	public Phone(String na, String un) {
		this.name=na;
		this.num=nu;
	}
	public void print{
		System.out.println("휴대폰 정보");
	}   System.out.println("폰 기종"+this.name);
	   System.out.println("폰번호 :"+this.num);
	   
}
class SmartPhone extends Phone{
	private String androidver;
	private String account; //
	멤버변수 : androidver, account, name. num
	부모 클래스가 생성자가 만ㄷ들어지면 자식 클래스도 생성자도 만들어짐
	//ㅇ이를 위해서, super()를 주로 사용
	public SmartPhone(String na, String nu, String a) {
		super(na, nu);
		this.androidver="13";
	this.account=a;
		
	}
	public void print() {
		System.out.println("스마트폰 정보");
		System.out.println("폰 기종: "+this.getNum());
		System.out.println("폰 번호: "+this.getNum());
		System.out.println("안드로이드 버전: "+this.androidver());
		System.out.println("계정 :"+this.account);
	}
}

public class ssssssss {
      public static void main(String args[]) {
    	  
    	  Phone p=nuew Phone("보디가드", "010=9229=5004");
    	  SmartPhone sp=new Smartphone("갈랙서 20", 52, "010=9229-6005");
    	  
    	  p.print();  // phone의 print()실행
    	  System.out.println();
    	  sp.print(); //smart
    	  
      }
}
