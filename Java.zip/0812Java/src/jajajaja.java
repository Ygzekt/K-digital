
abstract class Animal{//동물 클래스	
	abstract String getName();
	abstract void printCry();	
}

class Cat extends Animal{//고양이 클래스 (Animal 클래스 구체화)
	private String name;
	public Cat() {
		this.name="고양이";
	}	
	//Animal 클래스의 추상 메소드 2가지 구현
	public String getName() {
	  return this.name;	
	}	
	public void printCry() {
		System.out.println("야옹"); 				
	}
}
class Dog extends Animal{//강아지 클래스 (Animal 클래스 구체화)
	private String name;
	public Dog() {
		this.name="강아지";
   }	
	
	public String getName() {
		return this.name;
	}
	public void printCry() {
		System.out.println("왈 왈 왈");
	}
	//이렇게 구현하고 나면 빨간줄이 없어짐.
}
public class jajajaja {
   public static void main(String args[]) {
      //고양이와 강아지 객체 생성
	   Cat c=new Cat();
	   Dog d=new Dog();
 	   //고양이의 울음소리는 야옹  c객체 이용해서 출력
	   System.out.print(c.getName()+"의 울음소리는 ");
	   c.printCry(); //"야오오옹"출력
	   //강아지의 울음소리는 왈왈왈 d객체 이용해서 출력
	   System.out.print(d.getName()+"의 울음소리는 ");
	   d.printCry();
	   
}
}