//extends를 이용한 상속을 계속 배워왔음
abstract class Person{	
	abstract public void printName();
	abstract public void print();			
}
class Me extends Person{//Person클래스를 구체화	
	private String name; //제 자신의 이름 저장.
	public Me(String n) {
		this.name=n; 		
	}
	public void printName() {
		//printName()을 상속받아 구체화하고있는 
		System.out.println("제 이름은 "+this.name+"입니다.");		
	}
	public void print() {
		System.out.println("잘 부탁드립니다,");
	}
	 //추상 메서드 2개를 구체화하고 나면 오류가 없어짐
	//반드시 추상 틀래스 안에 있는 추상 메소드에 대한 정의를 해야하맘
} 

public class Java0825{
	public static void main(String args[]) {
	  // Person p=new Person();
		Me m=new Me("이유나");
		m=printName(); //"이름은 이유나 입니다."
		m.print();    // "잘 부탁드립니다."
	}
}