import java.util.*;

public class Ans3052 {
	public static void main(String args[]) {
		Scanner s=new Scanner(System.in);
		int arr[]=new int[10];	// 10개 저장할 배열 선언
		for(int i=0;i<10;i++) {
			arr[i]=s.nextInt();	// 입력 하나씩 받고
		}
		
		int rest[]=new int [42];	// 배열 번호가 0부터 41까지
		for(int i=0;i<10;i++) {	// arr의 배열값 하나씩 갖고와서 연산
			int r;		// 나머지 임시로 저장할 변수
			r=arr[i]%42;	// 나머지 연산 수행
			rest[r]++;		// r을 배열 번호로 갖는 배열값을 1 더함
		}
		
		int cnt=0;	// 서로 다른 나머지 개수 저장
		for(int i=0;i<42;i++) {
			if(rest[i]>0) {	// 만약, 해당 번호를 나머지로 갖는 것이 하나라도 있었다면
				cnt++;	// cnt에 1 추가
			}
		}
		System.out.println(cnt);	// 정답
	}
}
